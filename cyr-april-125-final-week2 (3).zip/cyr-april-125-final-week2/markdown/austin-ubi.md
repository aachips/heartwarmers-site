A guaranteed basic income plan in one of Texas's largest cities reduced rates of housing insecurity. But some Texas lawmakers are not happy.

### Story by [Kenneth Niemeyer](https://www.businessinsider.com/author/kenneth-niemeyer)

* A guaranteed basic income program in Austin gave people $1,000 a month for a year.
* Most of the participants spent the no-string-attached cash on housing, a study of the program found.
* Participants who said they could afford a balanced meal also increased by 17%.

A [guaranteed basic income plan](https://www.businessinsider.com/denver-basic-income-project-ubi-extended-homelessness-poverty-2024-1) in one of Texas's largest cities reduced rates of housing insecurity. But some Texas lawmakers are not happy.

Austin was the first city in Texas to launch a [tax-payer-funded basic income program](https://www.businessinsider.com/universal-basic-income-texas-houston-harris-county-covid-relief-2023-12) when the Austin Guaranteed Income Pilot kicked off in May 2022. The program served 135 low-income families, each receiving up to $1,000 monthly. Funding for 85 families came from the City of Austin while philanthropic donations funded the other 50.

Read more at <https://www.businessinsider.com/austin-guarunteed-basic-income-gbi-ubi-housing-security-homeless-2024-1>