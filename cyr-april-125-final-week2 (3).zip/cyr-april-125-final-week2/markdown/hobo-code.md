At the 1889 National Hobo Convention in St. Louis, a strict ethical code was established for all hobos to follow. Here are some tips we could all use, no matter what you carry in your rucksack.

1. YOU DO YOU.

"Decide your own life, don't let another person run or rule you."

2. SHOW SOME RESPECT.

"When in town, always respect the local law and officials, and try to be a gentleman at all times."

3. DON'T BE AN OPPORTUNIST.

"Don't take advantage of someone who is in a vulnerable situation, locals or other hobos."

4. GET A JOB.

"Always try to find work, even if temporary, and always seek out jobs nobody wants. By doing so you not only help a business along, but ensure employment should you return to that town again."

5. BE A SELF-STARTER.

"When no employment is available, make your own work by using your added talents at crafts."

6. SET A GOOD EXAMPLE.

"Do not allow yourself to become a stupid drunk and set a bad example for locals' treatment of other hobos."

7. BE MINDFUL OF OTHERS.

"When jungling in town, respect handouts, do not wear them out, another hobo will be coming along who will need them as badly, if not worse than you."

8. DON'T LITTER.

"Always respect nature, do not leave garbage where you are jungling."

9. LEND A HAND.

"If in a community jungle, always pitch in and help."

10. PRACTICE GOOD HYGIENE.

"Try to stay clean, and boil up wherever possible."

11. BE COURTEOUS WHEN YOU'RE RIDING THE RAILS ...

"When traveling, ride your train respectfully, take no personal chances, cause no problems with the operating crew or host railroad, act like an extra crew member."

12. ... AND WHEN YOU'RE NOT.

"Do not cause problems in a train yard, another hobo will be coming along who will need passage through that yard."

13. HELP OUT THE KIDS.

"Help all runaway children, and try to induce them to return home."

14. SAME GOES FOR HOBOS.

"Help your fellow hobos whenever and wherever needed, you may need their help someday."

15. LEND YOUR VOICE.

"If present at a hobo court and you have testimony, give it. Whether for or against the accused, your voice counts!"

<em>Wait.. National Hobo Convention? Is that a real thing? Yes.</em>

"The National Hobo Convention is held on the second weekend of every August since 1900 in the town of Britt, Iowa, organized by the local Chamber of Commerce, and known throughout the town as the annual "Hobo Day" celebration."

<a href="https://www.atlasobscura.com/places/national-hobo-convention">https://www.atlasobscura.com/places/national-hobo-convention</a>

<a href="https://www.mentalfloss.com/article/68447/15-rules-hobo-ethical-code-1889">https://www.mentalfloss.com/article/68447/15-rules-hobo-ethical-code-1889</a>